package com.example.projeto2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Web extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela2);

        final EditText edt1 = (EditText) findViewById(R.id.edt_10);
        final EditText edt2 = (EditText) findViewById(R.id.edt_1);
        final EditText edt3 = (EditText) findViewById(R.id.edt_11);
        Button btn3 = (Button) findViewById(R.id.btn_soma);


        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = v1 + v2;

                edt3.setText(v3.toString());
            }


        });
        Button btn4 = (Button) findViewById(R.id.btn_subs);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = v1 - v2;

                edt3.setText(v3.toString());
            }
        });
        Button btn5 = (Button) findViewById(R.id.btn_mlt);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = v1 * v2;

                edt3.setText(v3.toString());

            }
        });
        Button btn6 = (Button) findViewById(R.id.btn_div);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = v1 / v2;

                edt3.setText(v3.toString());

            }
        });
        Button btn7 = (Button) findViewById(R.id.btn_prc);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = v1/100*v2;

                edt3.setText(v3.toString());

            }
        });
    }}