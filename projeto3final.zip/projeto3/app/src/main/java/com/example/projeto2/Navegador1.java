package com.example.projeto2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Navegador1 extends AppCompatActivity {
    Button btn9;
    EditText edtUrl;
    WebView webNvgd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela3);
        btn9=(Button) findViewById(R.id.btn_entrar);
        edtUrl=(EditText) findViewById(R.id.navegadorWeb);
        webNvgd=(WebView) findViewById(R.id.webView);

        webNvgd.setWebViewClient(new WebViewClient());

            btn9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    webNvgd.loadUrl(edtUrl.getText().toString());
            }
    });
}}
