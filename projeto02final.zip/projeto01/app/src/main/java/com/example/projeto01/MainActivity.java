package com.example.projeto01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText edt1;
    EditText edt2;
    EditText edt3;
    Button bt1;
    EditText res1;
    EditText res2;
    EditText res3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt1 = (EditText) findViewById(R.id.edt_consumo);
        edt2 = (EditText) findViewById(R.id.edt_couvert_artistico);
        edt3 = (EditText) findViewById(R.id.edt_dividir);
        bt1 = (Button) findViewById(R.id.bt_calcular);
        res1 = (EditText) findViewById(R.id.edt_servico);
        res2 = (EditText) findViewById(R.id.edt_conta_total);
        res3 = (EditText) findViewById(R.id.edt_valor_pessoa);
        //ação o botão e calculos.
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;
                Double r1;
                Double r2;
                Double r3;
                v1 = Double.parseDouble(edt1.getText().toString());
                v2 = Double.parseDouble(edt2.getText().toString());
                v3 = Double.parseDouble(edt3.getText().toString());
                r1= (v1+v2)/v3/100*10;
                r2= (v1+v2)+r1;
                r3= (v1+v2+r1)/v3;
                res1.setText(r1.toString());
                res2.setText(r2.toString());
                res3.setText(r3.toString());
            }
        });


            }
    }


